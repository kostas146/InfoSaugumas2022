package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.io.*;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Encoder;

public class CBC {

    @FXML
    TextField MessageInput;
    @FXML
    TextField KeyInput;
    @FXML
    Label Crypted;
    @FXML
    Label Normal;
    static String key ;
    String clean ;
    String encryptedString;
    private static final String initVector = "encryptionIntVec";

    public static String encrypt(String value) { // basic CBC encyption
        try {
            IvParameterSpec iv = new IvParameterSpec(initVector.getBytes("UTF-8"));
            SecretKeySpec skeySpec = new SecretKeySpec(key.getBytes("UTF-8"), "AES");

            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5PADDING");
            cipher.init(Cipher.ENCRYPT_MODE, skeySpec, iv);

            byte[] encrypted = cipher.doFinal(value.getBytes());
            return Base64.getEncoder().encodeToString(encrypted);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }
    public static String decrypt(String encrypted) { //basic CBC decryption
        try {
            IvParameterSpec iv = new IvParameterSpec(initVector.getBytes("UTF-8"));
            SecretKeySpec skeySpec = new SecretKeySpec(key.getBytes("UTF-8"), "AES");

            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5PADDING");
            cipher.init(Cipher.DECRYPT_MODE, skeySpec, iv);
            byte[] original = cipher.doFinal(Base64.getDecoder().decode(encrypted));

            return new String(original);
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return null;
    }

    public void GautiDuomenys(ActionEvent actionEvent) throws Exception {

        clean=MessageInput.getText(); //setting values from input
        key=KeyInput.getText(); //setting values from input
        if(key.isEmpty()|| key.length()!=16){ //pop up window to notify user about empty key
            final Stage dialog = new Stage();
            Label l = new Label();
            VBox dialogVbox = new VBox(20);
            dialogVbox.getChildren().add(new Label("Key is empty")); // message will be in the top left corner because it's not possible to center it using this type of crating windows
            Scene dialogScene = new Scene(dialogVbox, 300, 200);
            dialog.setScene(dialogScene);
            dialog.show();
            System.out.println("Key is empty");
        }
//creating  file and encrypting
        else{
             encryptedString = encrypt(clean);
            System.out.println("Encrypted String - " + encryptedString);

            try {
                File myObj = new File("Aes.txt");
                if (myObj.createNewFile()) {
                    System.out.println("File created: " + myObj.getName());
                } else {
                    System.out.println("File already exists.");
                }
            } catch (IOException e) {
                System.out.println("An error occurred.");
                e.printStackTrace();


            }
            try {
                String a;

                FileWriter myWriter = new FileWriter("Aes.txt");
                myWriter.write(String.valueOf(encryptedString)); //writing to file
                myWriter.close();
                System.out.println("Successfully wrote to the file.");
            } catch (IOException e) {
                System.out.println("An error occurred.");
                e.printStackTrace();
            }}

    }

    public void GautiRezultata(ActionEvent actionEvent) throws Exception {
        String file ="Aes.txt";
        BufferedReader reader = new BufferedReader(new FileReader(file));
        String reading=reader.readLine(); // setting value from file
        reader.close();
        String decryptedString = decrypt(reading); // decrypting from file
        System.out.println("After decryption - " + decryptedString);
      Crypted.setText(String.valueOf(encryptedString)); //setting javafx elemnts with values
        Normal.setText(decryptedString);//setting javafx elemnts with values
        FileWriter myWriter = new FileWriter("Aes.txt");//resets file
        myWriter.write(""); //writing to file
        myWriter.close();
    }


}
