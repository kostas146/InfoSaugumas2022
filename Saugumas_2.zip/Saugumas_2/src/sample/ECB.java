package sample;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.*;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class ECB {
    //Strings for javafx elements conversation
    String encryptedString;
    String Message="";
    String Key="";
//Javafx elements
    @FXML
    TextField MessageInput;
    @FXML
    TextField KeyInput;
    @FXML
    Label Crypted;
    @FXML
    Label Normal;

        private static SecretKeySpec secretKey;
        private static byte[] key;
//function to generate random char key
        public static void setKey(String myKey)
        {
            MessageDigest sha = null;
            try {
                key = myKey.getBytes("UTF-8");
                sha = MessageDigest.getInstance("SHA-1");
                key = sha.digest(key);
                key = Arrays.copyOf(key, 16);
                System.out.println(key);
                secretKey = new SecretKeySpec(key, "AES");
            }
            catch (NoSuchAlgorithmException e) {
                e.printStackTrace();
            }
            catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
        }
        //ECB encryption
        public static String encrypt(String strToEncrypt, String secret)
        {
            try
            {
                setKey(secret);
                Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
                cipher.init(Cipher.ENCRYPT_MODE, secretKey);
                return Base64.getEncoder().encodeToString(cipher.doFinal(strToEncrypt.getBytes("UTF-8")));
            }
            catch (Exception e)
            {
                System.out.println("Error while encrypting: " + e.toString());
            }
            return null;
        }
//ECB decryption
        public static String decrypt(String strToDecrypt, String secret)
        {
            try
            {
                setKey(secret);
                Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5PADDING");
                cipher.init(Cipher.DECRYPT_MODE, secretKey);
                return new String(cipher.doFinal(Base64.getDecoder().decode(strToDecrypt)));
            }
            catch (Exception e)
            {
                System.out.println("Error while decrypting: " + e.toString());
            }
            return null;
        }


    public void GautiDuomenys(ActionEvent actionEvent) throws IOException {
        Key = KeyInput.getText(); // Getting key from input
        Message = MessageInput.getText();// getting message from input

        if (Key.isEmpty() || Key.length() != 16) { //pop up window to notify user about empty key
            final Stage dialog = new Stage();
            Label l = new Label();
            VBox dialogVbox = new VBox(20);
            dialogVbox.getChildren().add(new Label("Key is empty")); // message will be in the top left corner because it's not possible to center it using this type of crating windows
            Scene dialogScene = new Scene(dialogVbox, 300, 200);
            dialog.setScene(dialogScene);
            dialog.show();
            System.out.println("Key is empty");

        } else {
            try {
                encryptedString = ECB.encrypt(Message, Key); // encrypting part
                System.out.println(encryptedString);
            } catch (Exception e) {
                e.printStackTrace();
            }
            try {
                FileWriter myWriter = new FileWriter("Aes.txt"); //creating file in named directory
                myWriter.write(String.valueOf(encryptedString));
                myWriter.close();
                System.out.println("Successfully wrote to the file.");
            } catch (IOException e) {
                System.out.println("An error occurred.");
                e.printStackTrace();
            }
        }
    }

    String fileMessage=null; // getting file message
    public void GautiRezultata(ActionEvent actionEvent) throws IOException {
        String file ="Aes.txt";

        BufferedReader reader = new BufferedReader(new FileReader(file));
        fileMessage = reader.readLine(); // reading message
        reader.close();
        try {

            String decryptedString = ECB.decrypt(fileMessage, Key) ; // decrypting message
            Crypted.setText(String.valueOf(fileMessage)); // setting elements with values
            Normal.setText(decryptedString); // setting elements with values
        } catch (Exception e) {
            e.printStackTrace();
        }
        FileWriter myWriter = new FileWriter("Aes.txt");
        myWriter.write(""); //writing to file
        myWriter.close();

    }
}

