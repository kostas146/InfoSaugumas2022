package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class Controller {
    String raktas2 = "";
    String zinute = "";
    String raktas = "";
    String Užkoduota_zinute = "";
    @FXML
    TextField MessageInput;
    @FXML
    TextField KeyInput;
    @FXML
    Label Užkoduota;
    @FXML
    Label Originali;

    public String generateKey(String str, String key) {
        int x = str.length();
        for (int i = 0; ; i++) {
            if (x == i)
                i = 0;
            if (key.length() == str.length())
                break;
            key += (key.charAt(i));
        }
        return key;
    }

    public String cipherText(String str, String key) {
        int keypozicija = 0;
        String cipher_text = "";
        char[] ch = new char[str.length()];
        for (int i = 0; i < str.length(); i++) {
            ch[i] = str.charAt(i);
        }
        char[] Keys = new char[generateKey(zinute, raktas).length()];

        for (int i = 0; i < generateKey(zinute, raktas).length(); i++) {
            Keys[i] = generateKey(zinute, raktas).charAt(i);
        }
        for (int i = 0; i < str.length(); i++) {
            if (keypozicija == generateKey(zinute, raktas).length())
                break;

            int number = (int) ch[i];
            number += (int) Keys[keypozicija];
            cipher_text += (char) number;
            keypozicija++;
            System.out.println(number);
        }
        return cipher_text;
    }

    public String Decode(String str, String key) {
        String Decoded_text = "";
        int keypozicija = 0;
        char[] ch = new char[str.length()];

        for (int i = 0; i < str.length(); i++) {
            ch[i] = str.charAt(i);
        }
        char[] Keys = new char[generateKey(zinute, raktas).length()];


        for (int i = 0; i < generateKey(zinute, raktas).length(); i++) {
            Keys[i] = generateKey(zinute, raktas).charAt(i);
        }
        for (int i = 0; i < str.length(); i++) {
            if (keypozicija == generateKey(zinute, raktas).length())
                break;

            int number = (Character) ch[i];

            number -= (int) Keys[keypozicija];

            Decoded_text += (char) number;
            keypozicija++;
        }


        return Decoded_text;
    }

    public void GautiDuomenys(ActionEvent actionEvent) {

        zinute = MessageInput.getText();
        raktas = KeyInput.getText();
        raktas2 = generateKey(zinute, raktas);
        System.out.println(cipherText(zinute, raktas2));

    }

    public void GautiRezultata(ActionEvent actionEvent) {
        Užkoduota.setText(cipherText(zinute, raktas2));
        Užkoduota_zinute = Užkoduota.getText();

        Originali.setText(Decode(Užkoduota_zinute, raktas2));

    }
}
